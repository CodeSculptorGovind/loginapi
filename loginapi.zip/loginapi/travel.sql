-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2022 at 03:26 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travel`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `user_type` enum('ADMIN','DRIVER','CUSTOMER') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'CUSTOMER',
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime NOT NULL DEFAULT current_timestamp(),
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active | 0=Inactive '
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `user_type`, `email`, `password`, `last_login`, `phone`, `created`, `modified`, `status`) VALUES
(1, 'govind', 'singh', 'CUSTOMER', 'test@gmail.com', '$2y$10$XIGWepdKpTCE9lRK6xEl9e5mWHK1hOgkP0ZUnS9SglNFxd69uc1ve', '2022-01-09 15:01:30', '98989898', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1),
(4, 'lissa', 'jong', 'DRIVER', 'driver@gmail.com', '$2y$10$nZVsMFXdyQpq6GgPUhUll.nOXX0FZfIwQxLm2c6l8v.i2Z1L1Dtn.', '2022-01-09 15:20:45', '98989899', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users_authentication`
--

CREATE TABLE `users_authentication` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expired_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_authentication`
--

INSERT INTO `users_authentication` (`id`, `users_id`, `token`, `expired_at`, `created_at`, `updated_at`) VALUES
(1, 1, '13254cbe121f50aaffce4c0fedec6fd07aed477e', '2022-01-10 02:23:02', '2022-01-09 18:53:02', '2022-01-09 18:53:02'),
(2, 1, 'b7e55f1a9c1c10d590bfca283d7a65c27ab41bc0', '2022-01-10 02:23:30', '2022-01-09 18:53:30', '2022-01-09 18:53:30'),
(3, 1, '16612d19127fa9fa18d0d8bd6da742d917df07c2', '2022-01-10 02:32:10', '2022-01-09 19:02:10', '2022-01-09 19:02:10'),
(4, 1, 'c60f9c98b3aa8d8d7364260e8ccb853a3f7bcdf5', '2022-01-10 02:33:50', '2022-01-09 19:03:50', '2022-01-09 19:03:50'),
(5, 1, '89da5cc5ce54a15aa852f1d8a2982a94c0f9277b', '2022-01-10 02:35:14', '2022-01-09 19:05:14', '2022-01-09 19:05:14'),
(6, 1, '46c301488adff8fd82145f8d5ddf303c7df9db7e', '2022-01-10 02:40:40', '2022-01-09 19:10:40', '2022-01-09 19:10:40'),
(7, 1, '245b6a7c9cbd9b3222a86a3fc503603116c2a348', '2022-01-10 02:42:51', '2022-01-09 19:12:51', '2022-01-09 19:12:51'),
(8, 1, '0f271b2e911f64f6a2475431df69bce5875fe767', '2022-01-10 02:43:57', '2022-01-09 19:13:57', '2022-01-09 19:13:57'),
(9, 1, '9d505033e1addfd9a99232e51686ed3cb5c24151', '2022-01-10 02:44:43', '2022-01-09 19:14:43', '2022-01-09 19:14:43'),
(10, 1, '221b7e1e5cd00eaed085d903480f0d87a7afa1bd', '2022-01-10 03:11:02', '2022-01-09 19:26:57', '2022-01-09 15:11:02'),
(11, 1, '4972fbc35b6459628496e7455da96af26f22fba7', '2022-01-10 03:01:30', '2022-01-09 19:31:30', '2022-01-09 19:31:30'),
(12, 4, '862d1089c1add41267094be4121fb05201593e9f', '2022-01-10 03:14:07', '2022-01-09 19:40:48', '2022-01-09 15:14:07'),
(13, 4, '1357a08ecb41e60b7536f882d2cd3d7016dafd11', '2022-01-10 03:24:07', '2022-01-09 19:50:46', '2022-01-09 15:24:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_authentication`
--
ALTER TABLE `users_authentication`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users_authentication`
--
ALTER TABLE `users_authentication`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
