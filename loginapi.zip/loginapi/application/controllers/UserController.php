<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserController extends CI_Controller {

	public function index()
	{
		
	}

	public function register()
	{
		//print_r($_POST);
		$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'POST'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else{
			$check_auth_client = $this->MyModel->check_auth_client();
			if($check_auth_client == true)
			{
				$hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
				$input=[
					'first_name'=>$_POST['first_name'],
					'last_name'=>$_POST['last_name'],
					'user_type'=>$_POST['user_type'],
					'email'=>$_POST['email'],
					'password'=>$hashed_password,
					'phone'=>$_POST['phone']
			];

			$result=$this->db->insert('users',$input);
			echo json_encode(array('status'=>'success'));
			}
		}
		echo json_encode(array('status'=>'failed'));

	}

	public function login()
	{
		$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'POST'){
			//json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {

			$check_auth_client = $this->MyModel->check_auth_client();
			//$check_auth_client=true;
			if($check_auth_client == true){
				$params = $_REQUEST;
		        
		        $email = $params['email'];
		        $password = $params['password'];

		        	
		        $response = $this->MyModel->login($email,$password);
				json_output($response['status'],$response);
			}
		}
	}

	public function detail($id)
	{
		$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'GET' || $this->uri->segment(3) == '' || is_numeric($this->uri->segment(3)) == FALSE){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
			$check_auth_client = $this->MyModel->check_auth_client();
			if($check_auth_client == true){
		        $response = $this->MyModel->auth();
		        if($response['status'] == 200){
		        	$resp = $this->MyModel->user_detail_data($id);
					json_output($response['status'],$resp);
		        }
			}
		}
	}


	public function logout()
	{
		$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'POST'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
			$check_auth_client = $this->MyModel->check_auth_client();
			if($check_auth_client == true){
		        $response = $this->MyModel->logout();
				json_output($response['status'],$response);
			}
		}
	}


    	

}
